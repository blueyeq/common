g++ test_fork.cpp -o test_fork
./test_fork
