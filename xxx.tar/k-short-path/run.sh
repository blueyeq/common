g++ k-shortest-path.cpp -o k-shortest-path
cat shortpath.in | ./k-shortest-path   

