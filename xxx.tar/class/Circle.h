#ifndef CIRCLE_H
#define CIRCLE_H

#include "Matrix.h"
#include "testBase.h"

namespace testBase{
	class Circle  {
		private:
			Base *base_member;
		public:
			Circle();
			~Circle();
			void BaseGetType();
	};


}





#endif
