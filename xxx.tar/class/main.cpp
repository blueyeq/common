#include "Circle.h"
#include "Matrix.h"
using namespace testBase;
int main(){
	
	Matrix mat;
	Circle circle;
	mat.getType();
	circle.BaseGetType();
	return 0;



}
