#include "Matrix.h"

namespace testBase{
	void Matrix::getType(){
		printf("my type is %d\n", type);
	}


}
