g++ -c httpRequest.cpp -I.
g++ -o main main.c httpRequest.o -I.
./main
