g++ -o test test.cpp
./test
