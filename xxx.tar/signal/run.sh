g++ sig.cpp -o sig
./sig
