#!/bin/env python
# _*_ encoding: utf-8 _*_
# _*_ coding: utf-8 _*_

import sys
import os

def init(row_size, col_size):
	global vis;
	vis = [[0] * col_size for i in xrange(row_size)];

if __name__ == '__main__':
	init()

